<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Artwork;
use Illuminate\Support\Facades\Session;

class ArtworkController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $artworks = Artwork::all();
        return view ('artworks.index', compact ('artworks'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('artworks.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $valid = $request->validate([
            'artName' => 'required',
            'description' => 'required',
            'arttype'=> 'required',
            'link'=> 'required',
            'imgArt'=> 'required',
        ]);
        $artwork = new Artwork();
        $artwork->artist_name = $valid['artName'];
        $artwork->description = $valid['description'];
        $artwork->art_type = $valid['arttype'];
        $artwork->media_link = $valid['link'];
        $artwork->cover_url = $valid['imgArt'];
        $artwork->save();
        return redirect()->route('artworks.index')->with('success', 'Create successfully');



    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $artwork = Artwork::where('id', $id)->first();
        $artwork->delete();
        return redirect()->route('artworks.index')->with('success', 'Author deleted successfully');
    }
}
