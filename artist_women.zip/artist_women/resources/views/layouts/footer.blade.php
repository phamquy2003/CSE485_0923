<br><br><br><br><br><br><br><br>
<footer>
  <div class="card text-center">
      <div class="card-header">
        TLU'S THUY LOI
      </div>
      <div class="card-body">
          <h5 class="card-title">Special title treatment</h5>
          <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
      </div>
  </div>
</footer>