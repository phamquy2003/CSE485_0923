@extends('layouts.base')

@section('main')
                    @if(session('success'))
                        <div class="=alert alert-success">
                            {{session('success')}}
                        </div>

                    @endif
    <table class="table">
        <thead>
            <tr>
                <th scope="col">ArtistID</th>
                <th scope="col">ArtistName</th>
                <th scope="col">Description</th>
                <th scope="col">Art Type</th>
                <th scope="col">Media Link</th>
                <th scope="col">Cover Image</th>
                <th scope="col">Edit</th>
                <th scope="col">Delete</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($artworks as $artwork)
            <tr>
                <td>{{$artwork->id}}</td>
                <td>{{$artwork->artist_name}}</td>
                <td>{{$artwork->description}}</td>
                <td>{{$artwork->art_type}}</td>
                <td>{{$artwork->media_link}}</td>
                <td><img width="100" height="100" src="{{ asset( $artwork->cover_url ) }}" alt=""></td>
                <td>
                     <a href="{{route('artworks.edit', ['artwork'=>$artwork])}}" class="btn"><i class="fa-solid fa-pen-to-square  text-primary"></i>
                    </a>
                </td>
                <td>
                    <!-- Button trigger modal -->
                    <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#exampleModal{{ $artwork->id }}">
                        <i class="fa-solid fa-trash text-danger"></i>
                    </button>
                    
                    <!-- Modal -->
                    <div class="modal fade" id="exampleModal{{$artwork->id}}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog        ">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    {{$artwork->id}}
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <form action="{{ route('artworks.destroy', $artwork->id) }}" method="POST">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
                
            </tr>

            @endforeach


        </tbody>
       
    </table>
@endsection