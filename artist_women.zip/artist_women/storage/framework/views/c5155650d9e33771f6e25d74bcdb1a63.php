<div class="container p-4 shadow">
    <div class="row">
        <div class="col-12">
            <h1>Artist Women</h1>
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" id="sinhvien" href="<?php echo e(route('artworks.index')); ?>" disabled>ArtWork</a>
                        </li>
                        <li class="nav-item">
                          <a href="<?php echo e(route('artworks.create')); ?>" class="btn btn-success">Add Artwork</a>
                      </li>
                        
                    </ul>
                </div>
            </nav>
        </div>
    </div>
  </div><?php /**PATH C:\xampp\html\laravel project\artist_women\resources\views/layouts/header.blade.php ENDPATH**/ ?>