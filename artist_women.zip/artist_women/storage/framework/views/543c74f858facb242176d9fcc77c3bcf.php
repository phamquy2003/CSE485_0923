

<?php $__env->startSection('main'); ?>
                    <?php if(session('success')): ?>
                        <div class="=alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>

                    <?php endif; ?>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">ArtistID</th>
                <th scope="col">ArtistName</th>
                <th scope="col">Description</th>
                <th scope="col">Art Type</th>
                <th scope="col">Media Link</th>
                <th scope="col">Cover Image</th>
                <th scope="col">Edit</th>
                <th scope="col">Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $artworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artwork): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($artwork->id); ?></td>
                <td><?php echo e($artwork->artist_name); ?></td>
                <td><?php echo e($artwork->description); ?></td>
                <td><?php echo e($artwork->art_type); ?></td>
                <td><?php echo e($artwork->media_link); ?></td>
                <td><img width="100" height="100" src="<?php echo e(asset( $artwork->cover_url )); ?>" alt=""></td>
                <td>
                     <a href="<?php echo e(route('artworks.edit', ['artwork'=>$artwork])); ?>" class="btn"><i class="fa-solid fa-pen-to-square  text-primary"></i>
                    </a>
                </td>
                <td>
                    <!-- Button trigger modal -->
                    <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($artwork->id); ?>">
                        <i class="fa-solid fa-trash text-danger"></i>
                    </button>
                    
                    <!-- Modal -->
                    <div class="modal fade" id="exampleModal<?php echo e($artwork->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog        ">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <?php echo e($artwork->id); ?>

                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <form action="<?php echo e(route('artworks.destroy', $artwork->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
                
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </tbody>
       
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\html\laravel project\artist_women\resources\views/artworks/index.blade.php ENDPATH**/ ?>