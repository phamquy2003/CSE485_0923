

<?php $__env->startSection('title', 'Add Artwork'); ?>

<?php $__env->startSection('main'); ?>
<form action="<?php echo e(route('artworks.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row mt-4">
        <div class="col-md-12">
            <div class="input-group mb-3">
                <span class="input-group-text" id="basic-addon1">ArtistName	</span>
                <input type="text" class="form-control" aria-label="Username" name="artName" aria-describedby="basic-addon1">
            </div>
            <div class="input-group mb-3">
                <span class="input-group-text" id="basic-addon1">Description</span>
                <input type="text" class="form-control" aria-label="Username" name="description" aria-describedby="basic-addon1">
            </div>
            <div class="input-group mb-3">
                <span class="input-group-text" id="basic-addon1">Art Type</span>
                <input type="text" class="form-control" aria-label="Username" name="arttype" aria-describedby="basic-addon1">
            </div>
            <div class="input-group mb-3">
                <span class="input-group-text" id="basic-addon1">Media Link</span>
                <input type="text" class="form-control" aria-label="Username" name="link" aria-describedby="basic-addon1">
            </div>
            <div class="input-group mb-3">
                <span class="input-group-text" id="basic-addon1">Cover Image</span>
                <input type="file" class="form-control-file" aria-label="Username" name="imgArt" aria-describedby="basic-addon1">
            </div>


        </div>
    </div>
    <button type="submit" class="btn btn-success mt-4">Save</button>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\html\laravel project\artist_women\resources\views/artworks/create.blade.php ENDPATH**/ ?>