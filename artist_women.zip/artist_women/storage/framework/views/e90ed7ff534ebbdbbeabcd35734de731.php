<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('/css/bootstrap.min.css')); ?>">
    <title>
        <?php echo $__env->yieldContent('title'); ?>
    </title>
</head>
<body>
    
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="container mt-5">
        <?php echo $__env->yieldContent('main'); ?>
    </div>
<script src="<?php echo e(asset('js/bootstrap.bundle.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\html\laravel project\quatrinh2\resources\views/layouts/base.blade.php ENDPATH**/ ?>